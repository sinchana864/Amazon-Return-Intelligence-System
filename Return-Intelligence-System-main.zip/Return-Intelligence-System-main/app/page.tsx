import ReturnIntelligenceDashboard from "@/components/ReturnIntelligenceDashboard";

export default function Home() {
  return <ReturnIntelligenceDashboard />;
}
