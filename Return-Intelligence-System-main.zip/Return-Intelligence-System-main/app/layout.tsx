import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Return Intelligence System",
  description: "CSV-powered dashboard for e-commerce return risk analysis"
};

export default function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
