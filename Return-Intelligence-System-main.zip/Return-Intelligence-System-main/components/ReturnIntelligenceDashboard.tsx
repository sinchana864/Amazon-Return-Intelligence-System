"use client";

import { type ChangeEvent, useCallback, useEffect, useMemo, useRef, useState } from "react";
import Papa from "papaparse";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from "recharts";

type ReturnRecord = {
  order_id: string;
  return_id: string;
  order_date: string;
  return_date: string;
  customer_id: string;
  city: string;
  pincode: string;
  delivery_hub: string;
  sku: string;
  product_name: string;
  selling_price: number;
  return_reason: string;
  issue_type: string;
  returned_item_observed: string;
  fraud_flag: string;
  refund_amount: number;
  return_shipping_fee: number;
  estimated_loss: number;
  safet_claim_status: string;
  risk_score: number;
};

type CsvRow = Partial<Record<keyof ReturnRecord, string>>;

type Filters = {
  query: string;
  fraudFlag: string;
  issueType: string;
  location: string;
};

type GroupMetric = {
  name: string;
  subtitle?: string;
  returns: number;
  fraudReturns: number;
  reviewReturns: number;
  loss: number;
  avgRisk: number;
  fraudRate: number;
};

type GroupRiskModel = "rowAverage" | "customer" | "sku" | "location";

type LogisticsMixupCase = {
  sku: string;
  returnedItemObserved: string;
  count: number;
  relatedIssueType: string;
  avgRisk: number;
};

type CsvExportRow = Record<string, string | number>;

const CSV_PATH = "/data/return_intelligence_data_foundation_15000_rows.csv";
const REQUIRED_COLUMNS: Array<keyof ReturnRecord> = [
  "order_id",
  "return_id",
  "order_date",
  "return_date",
  "customer_id",
  "city",
  "pincode",
  "delivery_hub",
  "sku",
  "product_name",
  "selling_price",
  "return_reason",
  "issue_type",
  "returned_item_observed",
  "fraud_flag",
  "refund_amount",
  "return_shipping_fee",
  "estimated_loss",
  "safet_claim_status"
];
const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0
});
const numberFormat = new Intl.NumberFormat("en-IN");
const CHART_COLORS = ["#38bdf8", "#34d399", "#f59e0b", "#f87171", "#a78bfa", "#22c55e"];

function parseNumber(value: string | number | undefined): number {
  if (typeof value === "number") {
    return Number.isFinite(value) ? value : 0;
  }

  const normalized = String(value ?? "").replace(/[,₹\s]/g, "");
  const parsed = Number.parseFloat(normalized);
  return Number.isFinite(parsed) ? parsed : 0;
}

function clampScore(score: number): number {
  if (!Number.isFinite(score)) {
    return 0;
  }
  return Math.min(100, Math.max(0, score));
}

function calculateRowRisk(row: Pick<ReturnRecord, "fraud_flag" | "issue_type" | "estimated_loss">): number {
  const normalizedFlag = normalizeFlag(row.fraud_flag);
  const normalizedIssue = row.issue_type.trim().toLowerCase();

  const baseScore = normalizedFlag === "Fraud" ? 40 : normalizedFlag === "Review" ? 20 : 0;
  const issueScore =
    {
      wrong_item: 25,
      missing_parts: 20,
      logistics_issue: 15,
      defective_claim: 10,
      buyer_remorse: 0
    }[normalizedIssue] ?? 0;
  const lossScore = row.estimated_loss >= 2000 ? 20 : row.estimated_loss >= 1000 ? 10 : 0;

  return clampScore(baseScore + issueScore + lossScore);
}

function normalizeCsvRows(rows: CsvRow[]): ReturnRecord[] {
  return rows
    .filter((row) => (row.order_id || row.return_id) && row.customer_id && row.sku)
    .map((row) => {
      const normalizedRow = {
        order_id: String(row.order_id ?? ""),
        return_id: String(row.return_id ?? ""),
        order_date: String(row.order_date ?? ""),
        return_date: String(row.return_date ?? ""),
        customer_id: String(row.customer_id ?? ""),
        city: String(row.city ?? ""),
        pincode: String(row.pincode ?? ""),
        delivery_hub: String(row.delivery_hub ?? ""),
        sku: String(row.sku ?? ""),
        product_name: String(row.product_name ?? ""),
        selling_price: parseNumber(row.selling_price),
        return_reason: String(row.return_reason ?? ""),
        issue_type: String(row.issue_type ?? ""),
        returned_item_observed: String(row.returned_item_observed ?? ""),
        fraud_flag: normalizeFlag(row.fraud_flag ?? ""),
        refund_amount: parseNumber(row.refund_amount),
        return_shipping_fee: parseNumber(row.return_shipping_fee),
        estimated_loss: parseNumber(row.estimated_loss),
        safet_claim_status: String(row.safet_claim_status ?? "")
      };

      return {
        ...normalizedRow,
        risk_score: calculateRowRisk(normalizedRow)
      };
    });
}

function getMissingColumns(fields?: string[]): string[] {
  if (!fields || fields.length === 0) {
    return REQUIRED_COLUMNS.map(String);
  }

  return REQUIRED_COLUMNS.filter((column) => !fields.includes(column)).map(String);
}

function normalizeFlag(flag: string): string {
  const normalized = flag.trim().toLowerCase();
  if (["true", "yes", "y", "1", "fraud"].includes(normalized)) {
    return "Fraud";
  }
  if (["review", "manual_review", "needs_review"].includes(normalized)) {
    return "Review";
  }
  if (["false", "no", "n", "0", "clean"].includes(normalized)) {
    return "Clean";
  }
  return flag.trim() || "Unknown";
}

function isFraud(flag: string): boolean {
  return normalizeFlag(flag) === "Fraud";
}

function isReview(flag: string): boolean {
  return normalizeFlag(flag) === "Review";
}

function getRiskLabel(score: number): "Low" | "Medium" | "High" {
  if (score <= 30) {
    return "Low";
  }
  if (score <= 60) {
    return "Medium";
  }
  return "High";
}

function riskClass(score: number): string {
  const label = getRiskLabel(score);
  if (label === "High") {
    return "border-red-400/40 bg-red-500/15 text-red-200";
  }
  if (label === "Medium") {
    return "border-amber-300/40 bg-amber-400/15 text-amber-100";
  }
  return "border-emerald-300/40 bg-emerald-400/15 text-emerald-100";
}

function avg(values: number[]): number {
  if (values.length === 0) {
    return 0;
  }
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

function groupBy(
  rows: ReturnRecord[],
  getKey: (row: ReturnRecord) => string,
  getSubtitle?: (row: ReturnRecord) => string,
  riskModel: GroupRiskModel = "rowAverage"
): GroupMetric[] {
  const groups = new Map<string, ReturnRecord[]>();

  rows.forEach((row) => {
    const key = getKey(row) || "Unknown";
    groups.set(key, [...(groups.get(key) ?? []), row]);
  });

  const groupedMetrics = Array.from(groups.entries()).map(([name, records]) => {
    const fraudReturns = records.filter((record) => isFraud(record.fraud_flag)).length;

    return {
      name,
      subtitle: getSubtitle?.(records[0]),
      returns: records.length,
      fraudReturns,
      reviewReturns: records.filter((record) => isReview(record.fraud_flag)).length,
      loss: records.reduce((sum, record) => sum + record.estimated_loss, 0),
      avgRisk: avg(records.map((record) => record.risk_score)),
      fraudRate: records.length === 0 ? 0 : (fraudReturns / records.length) * 100
    };
  });

  if (riskModel === "rowAverage") {
    return groupedMetrics;
  }

  const maxLoss = Math.max(...groupedMetrics.map((metric) => metric.loss), 0);
  const weights = {
    customer: { fraud: 60, review: 25, loss: 15 },
    sku: { fraud: 60, review: 20, loss: 20 },
    location: { fraud: 70, review: 20, loss: 10 }
  }[riskModel];

  return groupedMetrics.map((metric) => {
    const normalizedLossScore = maxLoss > 0 ? metric.loss / maxLoss : 0;
    const computedRiskScore =
      (metric.fraudReturns / metric.returns) * weights.fraud +
      (metric.reviewReturns / metric.returns) * weights.review +
      normalizedLossScore * weights.loss;

    return {
      ...metric,
      avgRisk: clampScore(computedRiskScore)
    };
  });
}

function Badge({ score }: { score: number }) {
  return (
    <span className={`inline-flex rounded-full border px-2.5 py-1 text-xs ${riskClass(score)}`}>
      {getRiskLabel(score)}
    </span>
  );
}

function downloadCsv(filename: string, rows: CsvExportRow[]) {
  const csv = Papa.unparse(rows.length > 0 ? rows : [{ message: "No rows available for current filters" }]);
  const blob = new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");

  link.href = url;
  link.download = filename;
  link.style.display = "none";
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 0);
}

function buildClaimText(record: ReturnRecord): string {
  return `SAFE-T Claim Review Draft

Dear Seller Support Team,

I am requesting review of a suspicious return case based on the return inspection details and computed risk indicators below.

Order ID: ${record.order_id}
Return ID: ${record.return_id}
SKU: ${record.sku}
Product name: ${record.product_name}
Return reason: ${record.return_reason}
Issue type: ${record.issue_type}
Returned item observed: ${record.returned_item_observed}
Refund amount: ${currency.format(record.refund_amount)}
Return shipping fee: ${currency.format(record.return_shipping_fee)}
Estimated loss: ${currency.format(record.estimated_loss)}
SAFE-T claim status: ${record.safet_claim_status || "Not available"}
Computed risk score: ${record.risk_score.toFixed(0)} (${getRiskLabel(record.risk_score)})

The return appears to require seller review because the returned item observations, issue type, refund exposure, and computed risk score indicate a possible mismatch or high-risk return event. Please review the attached/order evidence and advise on SAFE-T claim eligibility.

This text is generated for seller review only and is not auto-submitted to Amazon.`;
}

function ActionButton({
  children,
  onClick,
  variant = "secondary"
}: {
  children: React.ReactNode;
  onClick: () => void;
  variant?: "primary" | "secondary";
}) {
  const classes =
    variant === "primary"
      ? "border-cyan-300/40 bg-cyan-300 px-4 py-2 text-slate-950 hover:bg-cyan-200"
      : "border-white/10 bg-slate-800 px-4 py-2 text-slate-100 hover:border-cyan-300/60 hover:bg-slate-700";

  return (
    <button
      className={`rounded-xl border text-sm font-medium transition ${classes}`}
      onClick={onClick}
      type="button"
    >
      {children}
    </button>
  );
}

function StatCard({
  label,
  value,
  detail
}: {
  label: string;
  value: string;
  detail: string;
}) {
  return (
    <section className="rounded-2xl border border-white/10 bg-slate-900/78 p-5 shadow-2xl shadow-black/20 backdrop-blur">
      <p className="text-sm text-slate-400">{label}</p>
      <p className="mt-3 text-2xl font-semibold tracking-tight text-white">{value}</p>
      <p className="mt-2 text-xs text-slate-500">{detail}</p>
    </section>
  );
}

function Panel({
  title,
  children
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-2xl border border-white/10 bg-slate-900/72 p-5 shadow-2xl shadow-black/20">
      <h2 className="text-base font-semibold text-white">{title}</h2>
      <div className="mt-4">{children}</div>
    </section>
  );
}

function EmptyChart({ message }: { message: string }) {
  return (
    <div className="flex h-72 items-center justify-center rounded-xl border border-dashed border-slate-700 text-sm text-slate-400">
      {message}
    </div>
  );
}

function DataTable({
  columns,
  rows
}: {
  columns: string[];
  rows: Array<Array<React.ReactNode>>;
}) {
  return (
    <div className="max-h-[32rem] overflow-auto rounded-xl border border-white/5">
      <table className="w-full min-w-[720px] border-collapse text-left text-sm">
        <thead className="sticky top-0 z-10 bg-slate-900">
          <tr className="border-b border-white/10 text-xs uppercase text-slate-500">
            {columns.map((column) => (
              <th className="px-3 py-3 font-medium" key={column}>
                {column}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.length === 0 ? (
            <tr>
              <td className="px-3 py-5 text-slate-400" colSpan={columns.length}>
                No matching records
              </td>
            </tr>
          ) : (
            rows.map((row, index) => (
              <tr className="border-b border-white/5 text-slate-200" key={index}>
                {row.map((cell, cellIndex) => (
                  <td className="px-3 py-3 align-middle" key={`${index}-${cellIndex}`}>
                    {cell}
                  </td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

export default function ReturnIntelligenceDashboard() {
  const [records, setRecords] = useState<ReturnRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [uploadStatus, setUploadStatus] = useState<string | null>(null);
  const [selectedClaimRecord, setSelectedClaimRecord] = useState<ReturnRecord | null>(null);
  const [copyStatus, setCopyStatus] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [filters, setFilters] = useState<Filters>({
    query: "",
    fraudFlag: "All",
    issueType: "All",
    location: ""
  });

  const loadDefaultCsv = useCallback(() => {
    setLoading(true);
    setError(null);
    setUploadStatus(null);

    Papa.parse<CsvRow>(CSV_PATH, {
      download: true,
      header: true,
      skipEmptyLines: true,
      complete: (result) => {
        const missingColumns = getMissingColumns(result.meta.fields);

        if (missingColumns.length > 0) {
          setRecords([]);
          setError(`Default CSV has missing columns: ${missingColumns.join(", ")}`);
          setLoading(false);
          return;
        }

        const parsedRows = normalizeCsvRows(result.data);

        if (parsedRows.length === 0) {
          setRecords([]);
          setError("Default CSV did not contain any valid return rows");
          setLoading(false);
          return;
        }

        setRecords(parsedRows);
        setError(result.errors[0]?.message ? `CSV warning: ${result.errors[0].message}` : null);
        setLoading(false);
      },
      error: (parseError) => {
        if (parseError.message.toLowerCase().includes("not found")) {
          setError(null);
        } else {
          setError(`Could not load ${CSV_PATH}: ${parseError.message}`);
        }
        setLoading(false);
      }
    });
  }, []);

  useEffect(() => {
    loadDefaultCsv();
  }, [loadDefaultCsv]);

  const handleCsvUpload = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];

    if (!file) {
      return;
    }

    if (!file.name.toLowerCase().endsWith(".csv")) {
      setUploadStatus(null);
      setError("Upload failed: please select a .csv file");
      event.target.value = "";
      return;
    }

    setLoading(true);
    setError(null);
    setUploadStatus(null);

    Papa.parse<CsvRow>(file, {
      header: true,
      skipEmptyLines: true,
      complete: (result) => {
        const missingColumns = getMissingColumns(result.meta.fields);

        if (missingColumns.length > 0) {
          setError(`Upload failed: missing columns ${missingColumns.join(", ")}`);
          setUploadStatus(null);
          setLoading(false);
          return;
        }

        if (result.errors.length > 0) {
          setError(`Upload failed: ${result.errors[0].message}`);
          setUploadStatus(null);
          setLoading(false);
          return;
        }

        const parsedRows = normalizeCsvRows(result.data);

        if (parsedRows.length === 0) {
          setError("Upload failed: the CSV is empty or has no valid return rows");
          setUploadStatus(null);
          setLoading(false);
          return;
        }

        setRecords(parsedRows);
        setUploadStatus("CSV loaded successfully");
        setLoading(false);
      },
      error: (parseError) => {
        setError(`Upload failed: ${parseError.message}`);
        setUploadStatus(null);
        setLoading(false);
      }
    });
  };

  const handleClearData = () => {
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
    loadDefaultCsv();
  };

  const issueTypes = useMemo(
    () => Array.from(new Set(records.map((record) => record.issue_type).filter(Boolean))).sort(),
    [records]
  );

  const filteredRecords = useMemo(() => {
    const query = filters.query.trim().toLowerCase();
    const location = filters.location.trim().toLowerCase();

    return records.filter((record) => {
      const matchesQuery =
        query.length === 0 ||
        record.sku.toLowerCase().includes(query) ||
        record.customer_id.toLowerCase().includes(query);
      const matchesFraud =
        filters.fraudFlag === "All" || normalizeFlag(record.fraud_flag) === filters.fraudFlag;
      const matchesIssue = filters.issueType === "All" || record.issue_type === filters.issueType;
      const matchesLocation =
        location.length === 0 ||
        record.city.toLowerCase().includes(location) ||
        record.pincode.toLowerCase().includes(location);

      return matchesQuery && matchesFraud && matchesIssue && matchesLocation;
    });
  }, [filters, records]);

  const metrics = useMemo(() => {
    const totalLoss = filteredRecords.reduce((sum, record) => sum + record.estimated_loss, 0);
    const fraudReturns = filteredRecords.filter((record) => isFraud(record.fraud_flag)).length;
    const reviewCases = filteredRecords.filter(
      (record) => isReview(record.fraud_flag) || record.risk_score > 60
    ).length;

    return {
      totalReturns: filteredRecords.length,
      fraudReturns,
      reviewCases,
      totalLoss,
      avgRisk: avg(filteredRecords.map((record) => record.risk_score))
    };
  }, [filteredRecords]);

  const fraudSkuChart = useMemo(
    () =>
      groupBy(
        filteredRecords.filter((record) => isFraud(record.fraud_flag)),
        (record) => record.sku,
        (record) => record.product_name
      )
        .sort((a, b) => b.fraudReturns - a.fraudReturns || b.avgRisk - a.avgRisk)
        .slice(0, 10),
    [filteredRecords]
  );

  const fraudByPincodeChart = useMemo(
    () =>
      groupBy(
        filteredRecords.filter((record) => isFraud(record.fraud_flag)),
        (record) => record.pincode,
        (record) => record.city
      )
        .sort((a, b) => b.fraudReturns - a.fraudReturns || b.loss - a.loss)
        .slice(0, 10),
    [filteredRecords]
  );

  const issueDistribution = useMemo(
    () =>
      groupBy(filteredRecords, (record) => record.issue_type || "Unknown")
        .sort((a, b) => b.returns - a.returns)
        .slice(0, 8),
    [filteredRecords]
  );

  const lossBySkuChart = useMemo(
    () =>
      groupBy(filteredRecords, (record) => record.sku, (record) => record.product_name)
        .sort((a, b) => b.loss - a.loss)
        .slice(0, 10),
    [filteredRecords]
  );

  const customerRisk = useMemo(
    () =>
      groupBy(filteredRecords, (record) => record.customer_id, undefined, "customer")
        .sort((a, b) => b.avgRisk - a.avgRisk || b.fraudReturns - a.fraudReturns),
    [filteredRecords]
  );

  const highRiskCustomers = useMemo(() => customerRisk.slice(0, 10), [customerRisk]);

  const skuRisk = useMemo(
    () =>
      groupBy(filteredRecords, (record) => record.sku, (record) => record.product_name, "sku")
        .sort((a, b) => b.avgRisk - a.avgRisk || b.fraudRate - a.fraudRate || b.loss - a.loss),
    [filteredRecords]
  );

  const topSkuRisk = useMemo(() => skuRisk.slice(0, 10), [skuRisk]);

  const locationRisk = useMemo(
    () =>
      groupBy(
        filteredRecords,
        (record) => `${record.pincode} · ${record.delivery_hub}`,
        (record) => record.city,
        "location"
      )
        .sort((a, b) => b.avgRisk - a.avgRisk || b.fraudRate - a.fraudRate || b.loss - a.loss),
    [filteredRecords]
  );

  const topLocationRisk = useMemo(() => locationRisk.slice(0, 10), [locationRisk]);

  const logisticsMixupCases = useMemo<LogisticsMixupCase[]>(() => {
    const candidates = filteredRecords.filter((record) =>
      ["wrong_item", "logistics_issue"].includes(record.issue_type.trim().toLowerCase())
    );
    const groups = new Map<string, ReturnRecord[]>();

    candidates.forEach((record) => {
      const observed = record.returned_item_observed.trim() || "Unknown";
      const key = `${record.sku}::${observed.toLowerCase()}`;
      groups.set(key, [...(groups.get(key) ?? []), record]);
    });

    return Array.from(groups.values())
      .filter((recordsInGroup) => recordsInGroup.length > 3)
      .map((recordsInGroup) => {
        const issueTypes = Array.from(
          new Set(recordsInGroup.map((record) => record.issue_type).filter(Boolean))
        );

        return {
          sku: recordsInGroup[0].sku,
          returnedItemObserved: recordsInGroup[0].returned_item_observed || "Unknown",
          count: recordsInGroup.length,
          relatedIssueType: issueTypes.join(", "),
          avgRisk: avg(recordsInGroup.map((record) => record.risk_score))
        };
      })
      .sort((a, b) => b.avgRisk - a.avgRisk || b.count - a.count);
  }, [filteredRecords]);

  const alerts = useMemo(
    () => ({
      highRiskCustomers: customerRisk.filter((customer) => customer.avgRisk > 60).length,
      highRiskSkus: skuRisk.filter((sku) => sku.avgRisk > 60 || sku.fraudRate >= 50).length,
      riskyPincodes: locationRisk.filter(
        (location) => location.avgRisk > 60 || location.fraudRate >= 50
      ).length,
      logisticsMixups: logisticsMixupCases.length
    }),
    [customerRisk, locationRisk, logisticsMixupCases.length, skuRisk]
  );

  const recentCases = useMemo(
    () =>
      [...filteredRecords]
        .sort((a, b) => new Date(b.return_date).getTime() - new Date(a.return_date).getTime())
        .slice(0, 12),
    [filteredRecords]
  );

  const handleFilterChange = (key: keyof Filters, value: string) => {
    setFilters((current) => ({ ...current, [key]: value }));
  };

  const selectedClaimText = useMemo(
    () => (selectedClaimRecord ? buildClaimText(selectedClaimRecord) : ""),
    [selectedClaimRecord]
  );

  const exportRiskReport = () => {
    downloadCsv("return-risk-summary-report.csv", [
      {
        total_returns: metrics.totalReturns,
        fraud_returns: metrics.fraudReturns,
        review_cases: metrics.reviewCases,
        total_estimated_loss: metrics.totalLoss.toFixed(2),
        average_computed_risk_score: metrics.avgRisk.toFixed(1),
        high_risk_customers: alerts.highRiskCustomers,
        high_risk_skus: alerts.highRiskSkus,
        risky_pincodes: alerts.riskyPincodes,
        possible_logistics_mixups: alerts.logisticsMixups
      }
    ]);
  };

  const exportHighRiskCustomers = () => {
    downloadCsv(
      "high-risk-customers.csv",
      customerRisk.map((customer) => ({
        customer_id: customer.name,
        total_returns: customer.returns,
        fraud_returns: customer.fraudReturns,
        review_returns: customer.reviewReturns,
        total_loss: customer.loss.toFixed(2),
        computed_customer_risk_score: customer.avgRisk.toFixed(1),
        risk_label: getRiskLabel(customer.avgRisk)
      }))
    );
  };

  const exportHighRiskSkus = () => {
    downloadCsv(
      "high-risk-skus.csv",
      skuRisk.map((sku) => ({
        sku: sku.name,
        product_name: sku.subtitle ?? "",
        total_returns: sku.returns,
        fraud_returns: sku.fraudReturns,
        review_returns: sku.reviewReturns,
        total_estimated_loss: sku.loss.toFixed(2),
        fraud_rate_percent: sku.fraudRate.toFixed(1),
        computed_sku_risk_score: sku.avgRisk.toFixed(1),
        risk_label: getRiskLabel(sku.avgRisk)
      }))
    );
  };

  const exportLocationRisk = () => {
    downloadCsv(
      "location-risk.csv",
      locationRisk.map((location) => ({
        pincode_delivery_hub: location.name,
        city: location.subtitle ?? "",
        total_returns: location.returns,
        fraud_returns: location.fraudReturns,
        review_returns: location.reviewReturns,
        total_loss: location.loss.toFixed(2),
        fraud_rate_percent: location.fraudRate.toFixed(1),
        computed_location_risk_score: location.avgRisk.toFixed(1),
        risk_label: getRiskLabel(location.avgRisk)
      }))
    );
  };

  const openClaimModal = (record: ReturnRecord) => {
    setSelectedClaimRecord(record);
    setCopyStatus(null);
  };

  const copyClaimText = async () => {
    if (!selectedClaimText) {
      return;
    }

    await navigator.clipboard.writeText(selectedClaimText);
    setCopyStatus("Copied");
  };

  return (
    <main className="min-h-screen px-4 py-6 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <header className="flex flex-col gap-4 border-b border-white/10 pb-6 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="text-sm font-medium uppercase tracking-[0.2em] text-cyan-300">
              Return Intelligence System
            </p>
            <h1 className="mt-3 text-3xl font-semibold tracking-tight text-white sm:text-4xl">
              Returns risk command center
            </h1>
            <p className="mt-3 max-w-2xl text-sm leading-6 text-slate-400">
              Analyze customer fraud, SKU exposure, location risk, and estimated losses from the
              CSV foundation dataset.
            </p>
          </div>
          <div className="rounded-2xl border border-cyan-300/20 bg-cyan-300/10 px-4 py-3 text-sm text-cyan-100">
            {loading ? "Loading CSV" : `${numberFormat.format(filteredRecords.length)} filtered returns`}
          </div>
        </header>

        <section className="mt-6 rounded-2xl border border-white/10 bg-slate-950/65 p-4 shadow-2xl shadow-black/20">
          <div className="grid gap-4 lg:grid-cols-[1fr_auto] lg:items-end">
            <label className="space-y-2">
              <span className="text-xs font-medium uppercase text-slate-500">
                Upload Return Data CSV
              </span>
              <input
                accept=".csv,text/csv"
                className="w-full rounded-xl border border-white/10 bg-slate-900 px-3 py-2 text-sm text-slate-200 outline-none file:mr-4 file:rounded-lg file:border-0 file:bg-cyan-300 file:px-3 file:py-1.5 file:text-sm file:font-medium file:text-slate-950 transition focus:border-cyan-300"
                onChange={handleCsvUpload}
                ref={fileInputRef}
                type="file"
              />
            </label>
            <button
              className="rounded-xl border border-white/10 bg-slate-800 px-4 py-2 text-sm font-medium text-slate-100 transition hover:border-cyan-300/60 hover:bg-slate-700"
              onClick={handleClearData}
              type="button"
            >
              Clear Data
            </button>
          </div>
          <div className="mt-3 flex flex-col gap-2 text-sm sm:flex-row sm:items-center sm:justify-between">
            <p className="text-slate-500">
              {loading
                ? "Reading return data"
                : `Active dataset contains ${numberFormat.format(records.length)} valid rows`}
            </p>
            {uploadStatus ? <p className="text-emerald-300">{uploadStatus}</p> : null}
          </div>
        </section>

        <section className="mt-6 grid gap-3 rounded-2xl border border-white/10 bg-slate-950/65 p-4 md:grid-cols-2 xl:grid-cols-4">
          <label className="space-y-2">
            <span className="text-xs font-medium uppercase text-slate-500">SKU or customer</span>
            <input
              className="w-full rounded-xl border border-white/10 bg-slate-900 px-3 py-2 text-sm text-white outline-none transition focus:border-cyan-300"
              onChange={(event) => handleFilterChange("query", event.target.value)}
              placeholder="Search SKU / customer ID"
              value={filters.query}
            />
          </label>
          <label className="space-y-2">
            <span className="text-xs font-medium uppercase text-slate-500">Fraud flag</span>
            <select
              className="w-full rounded-xl border border-white/10 bg-slate-900 px-3 py-2 text-sm text-white outline-none transition focus:border-cyan-300"
              onChange={(event) => handleFilterChange("fraudFlag", event.target.value)}
              value={filters.fraudFlag}
            >
              <option>All</option>
              <option>Fraud</option>
              <option>Review</option>
              <option>Clean</option>
              <option>Unknown</option>
            </select>
          </label>
          <label className="space-y-2">
            <span className="text-xs font-medium uppercase text-slate-500">Issue type</span>
            <select
              className="w-full rounded-xl border border-white/10 bg-slate-900 px-3 py-2 text-sm text-white outline-none transition focus:border-cyan-300"
              onChange={(event) => handleFilterChange("issueType", event.target.value)}
              value={filters.issueType}
            >
              <option>All</option>
              {issueTypes.map((issueType) => (
                <option key={issueType}>{issueType}</option>
              ))}
            </select>
          </label>
          <label className="space-y-2">
            <span className="text-xs font-medium uppercase text-slate-500">City or pincode</span>
            <input
              className="w-full rounded-xl border border-white/10 bg-slate-900 px-3 py-2 text-sm text-white outline-none transition focus:border-cyan-300"
              onChange={(event) => handleFilterChange("location", event.target.value)}
              placeholder="Search location"
              value={filters.location}
            />
          </label>
        </section>

        {error ? (
          <div className="mt-5 rounded-2xl border border-amber-400/25 bg-amber-400/10 p-4 text-sm text-amber-100">
            {error}. Confirm the CSV is available at {CSV_PATH}.
          </div>
        ) : null}

        <section className="mt-6 rounded-2xl border border-white/10 bg-slate-950/65 p-4 shadow-2xl shadow-black/20">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h2 className="text-base font-semibold text-white">Export reports</h2>
              <p className="mt-1 text-sm text-slate-500">
                Downloads use the currently filtered return dataset.
              </p>
            </div>
            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
              <ActionButton onClick={exportRiskReport}>Export Risk Report CSV</ActionButton>
              <ActionButton onClick={exportHighRiskCustomers}>
                Export High-Risk Customers CSV
              </ActionButton>
              <ActionButton onClick={exportHighRiskSkus}>Export High-Risk SKUs CSV</ActionButton>
              <ActionButton onClick={exportLocationRisk}>Export Location Risk CSV</ActionButton>
            </div>
          </div>
        </section>

        <section className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <StatCard
            detail="Customers with average risk above 60"
            label="High-risk customers"
            value={numberFormat.format(alerts.highRiskCustomers)}
          />
          <StatCard
            detail="SKUs with high average risk or 50%+ fraud rate"
            label="High-risk SKUs"
            value={numberFormat.format(alerts.highRiskSkus)}
          />
          <StatCard
            detail="Pincode and hub pairs with high risk"
            label="Risky pincodes"
            value={numberFormat.format(alerts.riskyPincodes)}
          />
          <StatCard
            detail="Repeated wrong item or logistics issue patterns"
            label="Possible mix-ups"
            value={numberFormat.format(alerts.logisticsMixups)}
          />
        </section>

        <section className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
          <StatCard
            detail="Rows after active filters"
            label="Total returns"
            value={numberFormat.format(metrics.totalReturns)}
          />
          <StatCard
            detail="fraud_flag normalized as Fraud"
            label="Fraud returns"
            value={numberFormat.format(metrics.fraudReturns)}
          />
          <StatCard
            detail="Review flag or risk score above 60"
            label="Review cases"
            value={numberFormat.format(metrics.reviewCases)}
          />
          <StatCard
            detail="Sum of estimated_loss"
            label="Total estimated loss"
            value={currency.format(metrics.totalLoss)}
          />
          <StatCard
            detail="Mean computed row risk score"
            label="Average risk score"
            value={metrics.avgRisk.toFixed(1)}
          />
        </section>

        <section className="mt-6 grid gap-5 xl:grid-cols-2">
          <Panel title="Top fraud SKUs">
            {fraudSkuChart.length ? (
              <ResponsiveContainer height={300} width="100%">
                <BarChart data={fraudSkuChart}>
                  <CartesianGrid stroke="#1e293b" strokeDasharray="3 3" />
                  <XAxis dataKey="name" stroke="#94a3b8" tick={{ fontSize: 11 }} />
                  <YAxis stroke="#94a3b8" tick={{ fontSize: 11 }} />
                  <Tooltip
                    contentStyle={{ background: "#0f172a", border: "1px solid #334155" }}
                    formatter={(value) => numberFormat.format(Number(value))}
                  />
                  <Bar dataKey="fraudReturns" fill="#38bdf8" name="Fraud returns" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <EmptyChart message="No fraud SKU data for the selected filters" />
            )}
          </Panel>

          <Panel title="Fraud by pincode">
            {fraudByPincodeChart.length ? (
              <ResponsiveContainer height={300} width="100%">
                <BarChart data={fraudByPincodeChart}>
                  <CartesianGrid stroke="#1e293b" strokeDasharray="3 3" />
                  <XAxis dataKey="name" stroke="#94a3b8" tick={{ fontSize: 11 }} />
                  <YAxis stroke="#94a3b8" tick={{ fontSize: 11 }} />
                  <Tooltip
                    contentStyle={{ background: "#0f172a", border: "1px solid #334155" }}
                    formatter={(value) => numberFormat.format(Number(value))}
                  />
                  <Bar dataKey="fraudReturns" fill="#34d399" name="Fraud returns" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <EmptyChart message="No pincode fraud data for the selected filters" />
            )}
          </Panel>

          <Panel title="Issue type distribution">
            {issueDistribution.length ? (
              <ResponsiveContainer height={300} width="100%">
                <PieChart>
                  <Pie
                    data={issueDistribution}
                    dataKey="returns"
                    innerRadius={64}
                    nameKey="name"
                    outerRadius={105}
                    paddingAngle={3}
                  >
                    {issueDistribution.map((entry, index) => (
                      <Cell fill={CHART_COLORS[index % CHART_COLORS.length]} key={entry.name} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ background: "#0f172a", border: "1px solid #334155" }}
                    formatter={(value) => numberFormat.format(Number(value))}
                  />
                  <Legend wrapperStyle={{ color: "#cbd5e1", fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <EmptyChart message="No issue type data for the selected filters" />
            )}
          </Panel>

          <Panel title="Loss by SKU">
            {lossBySkuChart.length ? (
              <ResponsiveContainer height={300} width="100%">
                <BarChart data={lossBySkuChart}>
                  <CartesianGrid stroke="#1e293b" strokeDasharray="3 3" />
                  <XAxis dataKey="name" stroke="#94a3b8" tick={{ fontSize: 11 }} />
                  <YAxis stroke="#94a3b8" tick={{ fontSize: 11 }} />
                  <Tooltip
                    contentStyle={{ background: "#0f172a", border: "1px solid #334155" }}
                    formatter={(value) => currency.format(Number(value))}
                  />
                  <Bar dataKey="loss" fill="#f59e0b" name="Estimated loss" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <EmptyChart message="No SKU loss data for the selected filters" />
            )}
          </Panel>
        </section>

        <section className="mt-6 grid gap-5">
          <Panel title="High-risk customers">
            <DataTable
              columns={["Customer", "Returns", "Fraud", "Review", "Loss", "Avg risk", "Label"]}
              rows={highRiskCustomers.map((customer) => [
                customer.name,
                numberFormat.format(customer.returns),
                numberFormat.format(customer.fraudReturns),
                numberFormat.format(customer.reviewReturns),
                currency.format(customer.loss),
                customer.avgRisk.toFixed(1),
                <Badge key={`${customer.name}-risk`} score={customer.avgRisk} />
              ])}
            />
          </Panel>

          <Panel title="SKU risk table">
            <DataTable
              columns={[
                "SKU",
                "Product",
                "Returns",
                "Fraud",
                "Review",
                "Loss",
                "Fraud rate",
                "Label"
              ]}
              rows={topSkuRisk.map((sku) => [
                sku.name,
                <span className="line-clamp-1 max-w-72" key={`${sku.name}-product`}>
                  {sku.subtitle}
                </span>,
                numberFormat.format(sku.returns),
                numberFormat.format(sku.fraudReturns),
                numberFormat.format(sku.reviewReturns),
                currency.format(sku.loss),
                `${sku.fraudRate.toFixed(1)}%`,
                <Badge key={`${sku.name}-risk`} score={sku.avgRisk} />
              ])}
            />
          </Panel>

          <Panel title="Location / hub risk table">
            <DataTable
              columns={[
                "Pincode / hub",
                "City",
                "Returns",
                "Fraud",
                "Review",
                "Loss",
                "Fraud rate",
                "Label"
              ]}
              rows={topLocationRisk.map((location) => [
                location.name,
                location.subtitle,
                numberFormat.format(location.returns),
                numberFormat.format(location.fraudReturns),
                numberFormat.format(location.reviewReturns),
                currency.format(location.loss),
                `${location.fraudRate.toFixed(1)}%`,
                <Badge key={`${location.name}-risk`} score={location.avgRisk} />
              ])}
            />
          </Panel>

          <Panel title="Possible Logistics / Package Mix-up Cases">
            <DataTable
              columns={["SKU", "Returned item observed", "Count", "Related issue type", "Risk level"]}
              rows={logisticsMixupCases.slice(0, 12).map((mixupCase) => [
                mixupCase.sku,
                mixupCase.returnedItemObserved,
                numberFormat.format(mixupCase.count),
                mixupCase.relatedIssueType,
                <Badge key={`${mixupCase.sku}-${mixupCase.returnedItemObserved}`} score={mixupCase.avgRisk} />
              ])}
            />
          </Panel>

          <Panel title="Recent return cases">
            <DataTable
              columns={[
                "Return date",
                "Return ID",
                "Customer",
                "SKU",
                "Issue",
                "Fraud flag",
                "Loss",
                "Risk",
                "Claim"
              ]}
              rows={recentCases.map((record) => [
                record.return_date,
                record.return_id,
                record.customer_id,
                record.sku,
                record.issue_type,
                record.fraud_flag,
                currency.format(record.estimated_loss),
                <span
                  className={`inline-flex rounded-full border px-2.5 py-1 text-xs ${riskClass(record.risk_score)}`}
                  key={`${record.return_id}-risk`}
                >
                  {record.risk_score.toFixed(0)} · {getRiskLabel(record.risk_score)}
                </span>,
                <button
                  className="rounded-lg border border-cyan-300/30 bg-cyan-300/10 px-3 py-1.5 text-xs font-medium text-cyan-100 transition hover:bg-cyan-300/20"
                  key={`${record.return_id}-claim`}
                  onClick={() => openClaimModal(record)}
                  type="button"
                >
                  Generate Claim
                </button>
              ])}
            />
          </Panel>
        </section>

        {selectedClaimRecord ? (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 px-4 py-6 backdrop-blur-sm">
            <div className="max-h-[90vh] w-full max-w-3xl overflow-hidden rounded-2xl border border-white/10 bg-slate-900 shadow-2xl shadow-black/40">
              <div className="flex flex-col gap-3 border-b border-white/10 p-5 sm:flex-row sm:items-start sm:justify-between">
                <div>
                  <p className="text-xs font-medium uppercase tracking-[0.2em] text-cyan-300">
                    SAFE-T Claim Generator
                  </p>
                  <h2 className="mt-2 text-xl font-semibold text-white">
                    Claim draft for return {selectedClaimRecord.return_id}
                  </h2>
                  <p className="mt-2 text-sm text-slate-400">
                    Generated for seller review only. Nothing is submitted automatically.
                  </p>
                </div>
                <button
                  className="rounded-xl border border-white/10 bg-slate-800 px-3 py-2 text-sm text-slate-200 transition hover:bg-slate-700"
                  onClick={() => setSelectedClaimRecord(null)}
                  type="button"
                >
                  Close
                </button>
              </div>
              <div className="p-5">
                <textarea
                  className="h-96 w-full resize-none rounded-xl border border-white/10 bg-slate-950 p-4 text-sm leading-6 text-slate-100 outline-none focus:border-cyan-300"
                  readOnly
                  value={selectedClaimText}
                />
                <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <ActionButton onClick={copyClaimText} variant="primary">
                    Copy Claim Text
                  </ActionButton>
                  {copyStatus ? <p className="text-sm text-emerald-300">{copyStatus}</p> : null}
                </div>
              </div>
            </div>
          </div>
        ) : null}
      </div>
    </main>
  );
}
